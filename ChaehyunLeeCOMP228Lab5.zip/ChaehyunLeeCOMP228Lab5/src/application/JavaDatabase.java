
package application;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.Callback;
import java.sql.*;
import javax.sql.*;


public class JavaDatabase extends Application {

    public static final String BLANK = "";

    GridPane gridPane;
    Button insertGameButton, insertPlayerButton, mapPlayerGameButton, updatePlayerInfoButton, displayReportButton,
            insertPlayer, insertGame, mapPlayerGame, updatePlayer;
    Label playerIdLabel, firstNameLabel, lastNameLabel, addressLabel, postalCodeLabel, provinceLabel, phoneNumberLabel,
            gameTitleLabel, gamePlayedOnLabel, scoreLabel, selectPlayerLabel, selectGameLabel;
    TextField playerIdField, firstNameField, lastNameField, addressField, postalCodeField, provinceField,
            phoneNumberField, gameTitleField, scoreField;
    DatePicker playedDate;
    ComboBox<Player> playerCb;
    ComboBox<Game> gameCb;
    //TABLE VIEW AND DATA
    private ObservableList<ObservableList> data;
    private TableView tableview;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("GameApp");

        gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(25, 25, 25, 25));

        insertPlayerButton = new Button("INSERT PLAYER");
        insertGameButton = new Button("INSERT GAME");
        mapPlayerGameButton = new Button("MAP PLAYER & GAME");
        updatePlayerInfoButton = new Button("UPDATE PLAYER");
        displayReportButton = new Button("DISPLAY REPORT");

        gridPane.add(insertPlayerButton, 0, 0);
        gridPane.add(insertGameButton, 0, 1);
        gridPane.add(mapPlayerGameButton, 0, 2);
        gridPane.add(updatePlayerInfoButton, 0, 3);
        gridPane.add(displayReportButton, 0, 4);

        insertPlayerButton.setOnAction(actionEvent -> {
            GridPane grid = new GridPane();
            grid.setAlignment(Pos.CENTER);
            grid.setHgap(10);
            grid.setVgap(10);
            grid.setPadding(new Insets(25, 25, 25, 25));

            firstNameLabel = new Label("First Name:");
            grid.add(firstNameLabel, 0, 0);

            firstNameField = new TextField();
            grid.add(firstNameField, 1, 0);

            lastNameLabel = new Label("Last Name:");
            grid.add(lastNameLabel, 0, 1);

            lastNameField = new TextField();
            grid.add(lastNameField, 1, 1);

            addressLabel = new Label("Address:");
            grid.add(addressLabel, 0, 2);

            addressField = new TextField();
            grid.add(addressField, 1, 2);

            postalCodeLabel = new Label("Postal Code:");
            grid.add(postalCodeLabel, 0, 3);

            postalCodeField = new TextField();
            grid.add(postalCodeField, 1, 3);

            provinceLabel = new Label("Province:");
            grid.add(provinceLabel, 0, 4);

            provinceField = new TextField();
            grid.add(provinceField, 1, 4);

            phoneNumberLabel = new Label("Phone Number:");
            grid.add(phoneNumberLabel, 0, 5);

            phoneNumberField = new TextField();
            grid.add(phoneNumberField, 1, 5);

            insertPlayer = new Button("INSERT PLAYER");
            grid.add(insertPlayer, 1, 6);

            Scene insertPlayerScene = new Scene(grid, 600, 600);
            Stage insertPlayerWindow = new Stage();
            insertPlayerWindow.setScene(insertPlayerScene);
            insertPlayerWindow.setTitle("Insert Player");
            insertPlayerWindow.show();

            insertPlayer.setOnAction(ae -> {
                String firstName = firstNameField.getText();
                String lastName = lastNameField.getText();
                String address = addressField.getText();
                String postalCode = postalCodeField.getText();
                String province = provinceField.getText();
                String phoneNumber = phoneNumberField.getText();

                Player player = new Player(firstName, lastName, address, postalCode, province, phoneNumber);
                insertPlayerInfo(player);
                insertPlayerWindow.close();
            });
        });

        insertGameButton.setOnAction(actionEvent -> {
            GridPane grid = new GridPane();
            grid.setAlignment(Pos.CENTER);
            grid.setHgap(10);
            grid.setVgap(10);
            grid.setPadding(new Insets(25, 25, 25, 25));

            gameTitleLabel = new Label("Game Title");
            grid.add(gameTitleLabel, 0, 0);

            gameTitleField = new TextField();
            grid.add(gameTitleField, 1, 0);

            insertGame = new Button("INSERT GAME");
            grid.add(insertGame, 1, 1);

            Scene insertGameScene = new Scene(grid, 400, 300);
            Stage insertGameWindow = new Stage();
            insertGameWindow.setScene(insertGameScene);
            insertGameWindow.setTitle("Insert Game");
            insertGameWindow.show();

            insertGame.setOnAction(ae -> {
                String gameTitle = gameTitleField.getText();
                Game game = new Game(gameTitle);
                insertGameInfo(game);
                insertGameWindow.close();
            });

        });

        mapPlayerGameButton.setOnAction(actionEvent -> {
            GridPane grid = new GridPane();
            grid.setAlignment(Pos.CENTER);
            grid.setHgap(10);
            grid.setVgap(10);
            grid.setPadding(new Insets(25, 25, 25, 25));

            selectPlayerLabel = new Label("Select a player");
            grid.add(selectPlayerLabel, 0, 0);

            List<Player> players = getAllPlayersInfo();

            playerCb = new ComboBox<Player>();

            for (Player player : players) {
                playerCb.getItems().add(player);
            }

            grid.add(playerCb, 1, 0);

            selectGameLabel = new Label("Select a game");
            grid.add(selectGameLabel, 0, 1);

            List<Game> games = getAllGames();

            gameCb = new ComboBox<Game>();

            for (Game game : games) {
                gameCb.getItems().add(game);
            }
            grid.add(gameCb, 1, 1);

            gamePlayedOnLabel = new Label("Game Played On");
            grid.add(gamePlayedOnLabel, 0, 2);

            playedDate = new DatePicker();
            grid.add(playedDate, 1, 2);

            scoreLabel = new Label("Score");
            grid.add(scoreLabel, 0, 3);

            scoreField = new TextField();
            grid.add(scoreField, 1, 3);

            mapPlayerGame = new Button("MAP PLAYER & GAME");
            grid.add(mapPlayerGame, 1, 4);

            Scene insertGameScene = new Scene(grid, 600, 600);
            Stage insertGameWindow = new Stage();
            insertGameWindow.setScene(insertGameScene);
            insertGameWindow.setTitle("Insert Game");
            insertGameWindow.show();

            mapPlayerGame.setOnAction(ae -> {
                Player selectedPlayer = playerCb.getSelectionModel().getSelectedItem();
                alert("", String.valueOf(selectedPlayer.getPlayerId()), AlertType.ERROR);
                Game selectedGame = gameCb.getSelectionModel().getSelectedItem();

                LocalDate playedOn = playedDate.getValue();
                String score = scoreField.getText();

                PlayerGame playerGame = new PlayerGame(selectedGame.getGameId(), selectedPlayer.getPlayerId(), playedOn,
                        Integer.parseInt(score));
                insertPlayerGameInfo(playerGame);
            });

        });

        updatePlayerInfoButton.setOnAction(actionEvent -> {
            GridPane grid = new GridPane();
            grid.setAlignment(Pos.CENTER);
            grid.setHgap(10);
            grid.setVgap(10);
            grid.setPadding(new Insets(25, 25, 25, 25));

            firstNameLabel = new Label("First Name:");
            grid.add(firstNameLabel, 0, 0);

            firstNameField = new TextField();
            grid.add(firstNameField, 1, 0);

            lastNameLabel = new Label("Last Name:");
            grid.add(lastNameLabel, 0, 1);

            lastNameField = new TextField();
            grid.add(lastNameField, 1, 1);

            addressLabel = new Label("Address:");
            grid.add(addressLabel, 0, 2);

            addressField = new TextField();
            grid.add(addressField, 1, 2);

            postalCodeLabel = new Label("Postal Code:");
            grid.add(postalCodeLabel, 0, 3);

            postalCodeField = new TextField();
            grid.add(postalCodeField, 1, 3);

            provinceLabel = new Label("Province:");
            grid.add(provinceLabel, 0, 4);

            provinceField = new TextField();
            grid.add(provinceField, 1, 4);

            phoneNumberLabel = new Label("Phone Number:");
            grid.add(phoneNumberLabel, 0, 5);

            phoneNumberField = new TextField();
            grid.add(phoneNumberField, 1, 5);

            playerIdLabel = new Label("Player ID:");
            grid.add(playerIdLabel, 0, 6);

            playerIdField = new TextField();
            grid.add(playerIdField, 1, 6);

            updatePlayer = new Button("UPDATE PLAYER");
            grid.add(updatePlayer, 1, 7);

            Scene updatePlayerScene = new Scene(grid, 600, 600);
            Stage updatePlayerWindow = new Stage();
            updatePlayerWindow.setScene(updatePlayerScene);
            updatePlayerWindow.setTitle("Update Player");
            updatePlayerWindow.show();

            updatePlayer.setOnAction(ae -> {
                int id = Integer.parseInt(playerIdField.getText());
                String firstName = firstNameField.getText();
                String lastName = lastNameField.getText();
                String address = addressField.getText();
                String postalCode = postalCodeField.getText();
                String province = provinceField.getText();
                String phoneNumber = phoneNumberField.getText();

                Player player = new Player(id, firstName, lastName, address, postalCode, province, phoneNumber);
                updatePlayerInfo(player);
                updatePlayerWindow.close();
            });
        });

        displayReportButton.setOnAction(actionEvent -> {
            GridPane grid = new GridPane();
            grid.setAlignment(Pos.CENTER);
            grid.setHgap(10);
            grid.setVgap(10);
            grid.setPadding(new Insets(25, 25, 25, 25));

            //TableView
            tableview = new TableView();
            buildData();

            Scene displayReportScene = new Scene(tableview, 900, 600);
            Stage displayReportWindow = new Stage();
            displayReportWindow.setScene(displayReportScene);
            displayReportWindow.setTitle("Display Report Player And Game Report");
            displayReportWindow.show();

        });

        Scene scene = new Scene(gridPane, 300, 250);

        primaryStage.setTitle("Game Player GUI Java application SQLite database. !");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void insertPlayerGameInfo(PlayerGame playerGame) {
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            connection = SqliteConnection.getDBConnection();
            String query = "INSERT INTO PlayerAndGame VALUES (?, ?, ?, ?, ?)";
            statement = connection.prepareStatement(query);
            statement.setInt(1, getNextPlayerGameId());
            statement.setInt(2, playerGame.getGameId());
            statement.setInt(3, playerGame.getPlayerId());
            statement.setDate(4, java.sql.Date.valueOf(playerGame.getPlayingDate()));
            statement.setInt(5, playerGame.getScore());
            int count = statement.executeUpdate();
            if (count == 1) {
                this.alert("Success", "Player Mapped To Game Successfully", AlertType.INFORMATION);
            } else {
                this.alert("Failure", "Failed To Map Player To Game", AlertType.ERROR);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != statement) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (null != connection) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private int getNextPlayerGameId() {
        int nextGameId = 0;
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            connection = SqliteConnection.getDBConnection();
            String query = "SELECT MAX(playerGameID) FROM PlayerAndGame";
            statement = connection.prepareStatement(query);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                nextGameId = rs.getInt(1) + 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != statement) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (null != connection) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return nextGameId;

    }

    private List<Game> getAllGames() {
        List<Game> games = new ArrayList<Game>();
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            connection = SqliteConnection.getDBConnection();
            String query = "SELECT * FROM GAME";
            statement = connection.prepareStatement(query);
            ResultSet rs = statement.executeQuery();
            Game game = null;
            while (rs.next()) {
                game = new Game();
                game.setGameId(rs.getInt(1));
                game.setGameTitle(rs.getString(2));
                games.add(game);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != statement) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (null != connection) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return games;
    }

    private List<Player> getAllPlayersInfo() {
        List<Player> players = new ArrayList<Player>();
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            connection = SqliteConnection.getDBConnection();
            String query = "SELECT * FROM PLAYER";
            statement = connection.prepareStatement(query);
            ResultSet rs = statement.executeQuery();
            Player player = null;
            while (rs.next()) {
                player = new Player(rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7));
                player.setPlayerId(rs.getInt(1));
                players.add(player);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != statement) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (null != connection) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return players;
    }

    //CONNECTION DATABASE
    public void buildData() {
        Connection c;
        data = FXCollections.observableArrayList();
        try {
            c = SqliteConnection.getDBConnection();;
            //SQL FOR SELECTING ALL OF CUSTOMER
            String SQL = "SELECT p.player_Id, p.first_Name, p.last_Name, p.address, p.postal_Code, p.province, p.phone_Number, pg.score, g.game_Title\n"
                    + "FROM  Player p\n"
                    + "JOIN  PlayerAndGame pg\n"
                    + "ON p.player_Id = pg.player_ID\n"
                    + "JOIN  Game g\n"
                    + "ON g.game_Id = pg.game_ID";
            //ResultSet
            ResultSet rs = c.createStatement().executeQuery(SQL);

            /**
             * ********************************
             * TABLE COLUMN ADDED DYNAMICALLY * ********************************
             */
            for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {
                //We are using non property style for making dynamic table
                final int j = i;
                TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i + 1));
                col.setCellValueFactory(new Callback<CellDataFeatures<ObservableList, String>, ObservableValue<String>>() {
                    public ObservableValue<String> call(CellDataFeatures<ObservableList, String> param) {
                        return new SimpleStringProperty(param.getValue().get(j).toString());
                    }
                });

                tableview.getColumns().addAll(col);
//                System.out.println("Column [" + i + "] ");
            }

            /**
             * ******************************
             * Data added to ObservableList * ******************************
             */
            while (rs.next()) {
                //Iterate Row
                ObservableList<String> row = FXCollections.observableArrayList();
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    //Iterate Column
                    row.add(rs.getString(i));
                }
//                System.out.println("Row [1] added " + row);
                data.add(row);

            }

            //FINALLY ADDED TO TableView
            tableview.setItems(data);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error on Building Data");
        }
    }

    private void insertGameInfo(Game game) {
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            connection = SqliteConnection.getDBConnection();
            String query = "INSERT INTO GAME VALUES (?, ?)";
            statement = connection.prepareStatement(query);
            statement.setInt(1, getNextGameId());
            statement.setString(2, game.getGameTitle());
            int count = statement.executeUpdate();
            if (count == 1) {
                this.alert("Success", "Game Information inserted to DB successfully", AlertType.INFORMATION);
            } else {
                this.alert("Failure", "Some error while adding Game Information", AlertType.ERROR);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != statement) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (null != connection) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private int getNextGameId() {
        int nextGameId = 0;
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            connection = SqliteConnection.getDBConnection();
            String query = "SELECT MAX(game_Id) FROM GAME";
            statement = connection.prepareStatement(query);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                nextGameId = rs.getInt(1) + 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != statement) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (null != connection) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return nextGameId;

    }

    private void insertPlayerInfo(Player player) {
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            connection = SqliteConnection.getDBConnection();
            String query = "INSERT INTO PLAYER VALUES (?, ?, ?, ?, ?, ?, ?)";
            statement = connection.prepareStatement(query);
            statement.setInt(1, getNextPlayerId());
            statement.setString(2, player.getFirstName());
            statement.setString(3, player.getLastName());
            statement.setString(4, player.getAddress());
            statement.setString(5, player.getPostalCode());
            statement.setString(6, player.getProvince());
            statement.setString(7, player.getPhoneNumber());
            int count = statement.executeUpdate();
            if (count == 1) {
                this.alert("Success", "Player Information inserted to DB successfully", AlertType.INFORMATION);
            } else {
                this.alert("Failure", "Some error while adding Player Information", AlertType.ERROR);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != statement) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (null != connection) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void updatePlayerInfo(Player player) {
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            connection = SqliteConnection.getDBConnection();
            String query = "UPDATE PLAYER SET first_Name = ?, last_Name = ?, address = ?, postal_Code = ?, province = ?, phone_Number = ? WHERE player_Id = ?";
            statement = connection.prepareStatement(query);
            statement.setString(1, player.getFirstName());
            statement.setString(2, player.getLastName());
            statement.setString(3, player.getAddress());
            statement.setString(4, player.getPostalCode());
            statement.setString(5, player.getProvince());
            statement.setString(6, player.getPhoneNumber());
            statement.setInt(7, player.getPlayerId());
            int count = statement.executeUpdate();
            if (count == 1) {
                this.alert("Success", "Player Information updated successfully", AlertType.INFORMATION);
            } else {
                this.alert("Failure", "Some error while updating Player Information", AlertType.ERROR);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != statement) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (null != connection) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private int getNextPlayerId() {
        int nextPlayerId = 0;
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            connection = SqliteConnection.getDBConnection();
            String query = "SELECT MAX(player_id) FROM PLAYER";
            statement = connection.prepareStatement(query);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                nextPlayerId = rs.getInt(1) + 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != statement) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (null != connection) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return nextPlayerId;

    }

    // Will show alert messages
    public void alert(String title, String message, AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Executon starts from here
        launch(args);
    }

}

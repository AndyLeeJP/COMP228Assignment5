
package application;

import java.time.LocalDate;


public class PlayerGame {

    private int playerGameId;
    private int gameId;
    private int playerId;
    private LocalDate playingDate;
    private int score;

    public PlayerGame() {
    }

    /**
     *
     * @param playerGameId
     * @param gameId
     * @param playerId
     * @param playingDate
     * @param score
     */
    public PlayerGame(int playerGameId, int gameId, int playerId, LocalDate playingDate, int score) {
        this.playerGameId = playerGameId;
        this.gameId = gameId;
        this.playerId = playerId;
        this.playingDate = playingDate;
        this.score = score;
    }

    /**
     *
     * @param gameId
     * @param playerId
     * @param playingDate
     * @param score
     */
    public PlayerGame(int gameId, int playerId, LocalDate playingDate, int score) {
        this.gameId = gameId;
        this.playerId = playerId;
        this.playingDate = playingDate;
        this.score = score;
    }

    /**
     * Get the value of score
     *
     * @return the value of score
     */
    public int getScore() {
        return score;
    }

    /**
     * Set the value of score
     *
     * @param score new value of score
     */
    public void setScore(int score) {
        this.score = score;
    }

    /**
     * Get the value of playingDate
     *
     * @return the value of playingDate
     */
    public LocalDate getPlayingDate() {
        return playingDate;
    }

    /**
     * Set the value of playingDate
     *
     * @param playingDate new value of playingDate
     */
    public void setPlayingDate(LocalDate playingDate) {
        this.playingDate = playingDate;
    }

    /**
     * Get the value of playerId
     *
     * @return the value of playerId
     */
    public int getPlayerId() {
        return playerId;
    }

    /**
     * Set the value of playerId
     *
     * @param playerId new value of playerId
     */
    public void setPlayerId(int playerId) {
        this.playerId = playerId;
    }

    /**
     * Get the value of gameId
     *
     * @return the value of gameId
     */
    public int getGameId() {
        return gameId;
    }

    /**
     * Set the value of gameId
     *
     * @param gameId new value of gameId
     */
    public void setGameId(int gameId) {
        this.gameId = gameId;
    }

    /**
     * Get the value of playerGameId
     *
     * @return the value of playerGameId
     */
    public int getPlayerGameId() {
        return playerGameId;
    }

    /**
     * Set the value of playerGameId
     *
     * @param playerGameId new value of playerGameId
     */
    public void setPlayerGameId(int playerGameId) {
        this.playerGameId = playerGameId;
    }

}

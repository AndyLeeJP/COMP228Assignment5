
package application;

import java.sql.Connection;
import java.sql.DriverManager;
import javafx.scene.control.Alert;


public class SqliteConnection {

    static Connection conn = null;

    public static Connection getDBConnection() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@ 199.212.26.208:1521:SQLD","comp214_M21_39", "password");

            return conn;
        } catch (Exception e) {
            alert("Failure", "Error Connecting to DB!" + e.getMessage(), Alert.AlertType.ERROR);
            return null;
        }
    }

    public static void alert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

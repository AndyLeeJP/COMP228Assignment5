
package application;


public class Game {

    private int gameId;
    private String gameTitle;

    public Game() {
    }

    /**
     *
     * @param gameId
     * @param gameTitle
     */
    public Game(int gameId, String gameTitle) {
        this.gameId = gameId;
        this.gameTitle = gameTitle;
    }

    /**
     *
     * @param gameTitle
     */
    public Game(String gameTitle) {
        this.gameTitle = gameTitle;
    }

    /**
     * Get the value of gameTitle
     *
     * @return the value of gameTitle
     */
    public String getGameTitle() {
        return gameTitle;
    }

    /**
     * Set the value of gameTitle
     *
     * @param gameTitle new value of gameTitle
     */
    public void setGameTitle(String gameTitle) {
        this.gameTitle = gameTitle;
    }

    /**
     * Get the value of gameId
     *
     * @return the value of gameId
     */
    public int getGameId() {
        return gameId;
    }

    /**
     * Set the value of gameId
     *
     * @param gameId new value of gameId
     */
    public void setGameId(int gameId) {
        this.gameId = gameId;
    }

    @Override
    public String toString() {
        return "Game{" + "gameId=" + gameId + ", gameTitle=" + gameTitle + '}';
    }
    

}
